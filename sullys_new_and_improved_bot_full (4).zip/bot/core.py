from .budget import allocation_by_budget,funnel_split
from .strategies import PLATFORM_TEMPLATES
from .audiences import AUDIENCE_BANK

def generate_strategy(niche,budget,goal,geo,competitors):
 niche=niche.lower()
 if niche not in AUDIENCE_BANK: raise ValueError('Unsupported niche: '+niche)
 allocation=allocation_by_budget(budget,goal)
 funnel=funnel_split(budget)
 platform_plans={}
 for platform,pct in allocation.items():
  if platform in PLATFORM_TEMPLATES:
   plan=PLATFORM_TEMPLATES[platform](niche,budget)
   plan['budget_pct']=pct
   plan['notes']={'geo':geo,'competitors':competitors,'goal':goal}
   platform_plans[platform]=plan
 return {'niche':niche,'budget':budget,'goal':goal,'geo':geo,'allocation':allocation,'funnel_split':funnel,'platforms':platform_plans}