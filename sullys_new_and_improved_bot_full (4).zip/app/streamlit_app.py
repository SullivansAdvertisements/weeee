
import streamlit as st
import pandas as pd
import json, os
from datetime import datetime
from bot.core import generate_strategy

st.set_page_config(page_title="Sully's New & Improved Marketing Bot", page_icon="📈", layout="wide")
st.title("📈 Sully's New & Improved Marketing Bot")
st.caption("Full-featured strategy & campaign template generator for Meta, Google/YouTube, TikTok, Twitter/X.")

with st.sidebar:
    st.header("Inputs")
    niche = st.selectbox("Niche", ["clothing","consignment","musician"])
    budget = st.number_input("Monthly Budget (USD)", min_value=100.0, value=2500.0, step=50.0)
    goal = st.selectbox("Primary Goal", ["sales","conversions","leads","awareness","traffic"])
    geo = st.text_input("Geo (country/city or radius)", "US")
    competitors_raw = st.text_area("Competitors (one per line)", "")
    competitors = [c.strip() for c in competitors_raw.split("\n") if c.strip()]
    run = st.button("Generate Plan")

if run:
    plan = generate_strategy(niche, budget, goal, geo, competitors)

    st.subheader("📊 Budget Allocation & Funnel Split")
    col1, col2 = st.columns(2)
    col1.bar_chart(pd.DataFrame(plan["allocation"], index=["%"]).T)
    col2.bar_chart(pd.DataFrame(plan["funnel_split"], index=["%"]).T)

    st.subheader("🧩 Platform Plans")
    for platform, cfg in plan["platforms"].items():
        with st.expander(f"{platform.upper()} Plan", expanded=False):
            st.json(cfg)

    st.subheader("⬇️ Export")
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    export_dir = f"exports/{ts}_{niche}_{geo.replace(' ','_')}"
    os.makedirs(export_dir, exist_ok=True)
    json_path = os.path.join(export_dir, "plan.json")
    md_path = os.path.join(export_dir, "plan.md")

    with open(json_path, "w") as f:
        json.dump(plan, f, indent=2)

    def md_section(title): return f"\n\n## {title}\n"
    md = f"# Strategy — {niche.title()} ({geo}) — ${budget:,.0f}/mo\n"
    md += f"*Goal:* {goal}\n"
    md += md_section("Allocation")
    for k,v in plan["allocation"].items():
        md += f"- **{k}**: {v}%\n"
    md += md_section("Funnel Split")
    for k,v in plan["funnel_split"].items():
        md += f"- **{k}**: {v}%\n"
    md += md_section("Platforms")
    for p,cfg in plan["platforms"].items():
        md += f"\n### {p.upper()}\n"
        md += f"- Objective: {cfg.get('objective','')}\n"
        if 'budget_pct' in cfg:
            md += f"- Budget %: {cfg['budget_pct']}%\n"
        if 'campaign_structure' in cfg:
            md += f"- Structure Keys: {list(cfg['campaign_structure'].keys())}\n"
        md += f"- KPIs: {', '.join(cfg.get('kpis', []))}\n"

    with open(md_path, "w") as f:
        f.write(md)

    st.success(f"Exported to: {export_dir}")
    with open(json_path, "rb") as f:
        st.download_button("Download plan.json", data=f, file_name="plan.json", mime="application/json")
    with open(md_path, "rb") as f:
        st.download_button("Download plan.md", data=f, file_name="plan.md", mime="text/markdown")
else:
    st.info("Use the sidebar to select a niche, budget, goal, and geo. Paste competitor links and click **Generate Plan**.")
